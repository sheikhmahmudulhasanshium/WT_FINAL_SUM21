<html>
    <head>
    <link rel="stylesheet" href="CSS/mystyles.css">
    </head>
    <body>
        <form align="center">
        <input type="text"name="search" >
        <input type="submit" name="searchbutton"name="searchbtn" value="Search" class="searchbtn">
        </form>
    </body>
</html>