<?php
?>
<html>
    <body>
        <h1>
            How many stars do you want to give us?
        </h1>
        <input type="radio" name="stars">1*
        <input type="radio" name="stars">2*
        <input type="radio" name="stars">3*
        <input type="radio" name="stars">4*
        <input type="radio" name="stars">5*
        <br>
        <input type="text" placeholder="Email Adreess:">
        <br>
        <textarea name="feedback" id="" cols="30" rows="10"placeholder="Write your review here...."></textarea>
        <br>
        <input type="submit" value="Submit">
    </body>
</html>