<?php ?>
<html>
    <body >
        <h1>
            Your Password Has been Reset <br>
            <a target="_blank" href="login.html">Login</a>
        </h1>
    </body>
</html>