<html>
<head>
</head>
<body>
	<table align="center" style="border:2px solid Blue;">
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan="3" align="center"><h1>Admin Panel</h1></td>
		</tr>
		<tr>
			<td colspan="3"><hr></td>
		</tr>
		<tr>
			<td>Want to Add Employee?<td>
			<td><a href ="Add_Employee.php"><input type="button" value="Add"> </a></td>
		</tr>
		<tr>
			<td>Want to Remove Employee?<td>
			<td><a href ="Remove_Employee.php"><input type="button" value="Remove"> </a></td>
		</tr>
		<tr>
			<td>Want to Add Category?<td>
			<td><a href ="AddCatagory.php"><input type="button" value="Add"> </a></td>
		</tr>
		<tr>
			<td>Want to Edit Category?<td>
			<td><a href ="EditCatagory.php"><input type="button" value="Edit"> </a></td>
		</tr>
		<tr>
			<td>Want to Edit Customer?<td>
			<td><a href ="EditCustomerProfile.php"><input type="button" value="Edit"> </a></td>
		</tr>
	</table>		
</body>			
</html>