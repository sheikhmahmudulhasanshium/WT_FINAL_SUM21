<html>
<head>
</head>
<body>
	<table align="center">
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan="3" align="center"><h1>Receiptionist Panel</h1></td>
		</tr>
		<tr>
			<td colspan="3"><hr></td>
		</tr>
		<tr>
			<td>Want to Add Customer?<td>
			<td><a href ="CustomerAdd.php"><input type="button" value="Add"> </a></td>
		</tr>
	</table>		
</body>			
</html>