<html>
    <body>
	<h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	Restaurants</h1>
	<table>
	
	<tr>
	<td>
	<?php
	echo "<form action = 'Buffet.php' method='post'>";
	echo "<input type='Submit' value='Buffet'>";
	echo "</form>";
	?>
	</td>
	<td><img width="400px" height="300px" src="Buffet.jpg"></td>
	<td><?php
	echo "<form action = 'Classic.php' method='post'>";
	echo "<input type='Submit' value='Classic'>";
	echo "</form>";
	?></td>
	<td><img width="400px" height="300px" src="Classic.jpg"></td></tr>
	
	<tr><td><?php
	echo "<form action = 'KababSegment.php' method='post'>";
	echo "<input type='Submit' value='Kabab Segment'>";
	echo "</form>";
	?></td>
	<td><img width="400px" height="300px" src="KababSegment.jpg"></td></tr>
	
	
	
	<tr><td><?php
	/*echo "<form action = 'Buffet.php' method='post'>";
	echo "<input type='Submit' value='Roof TOp'>";
	echo "</form>";*/
	?></h1></td>
	<!--<td><img width="300px" height="300px" src="RoofTOp.png"></td>
	<td><?php
	/*echo "<form action = 'Buffet.php' method='post'>";
	echo "<input type='Submit' value='Pool Cafe'>";
	echo "</form>";*/
	?></td>
	<td><h1><img width="300px" height="300px" src="PoolCafe.jpg"></td></h1></tr>-->
	
	
	</table>
	</form>
	
	</body>
</html>