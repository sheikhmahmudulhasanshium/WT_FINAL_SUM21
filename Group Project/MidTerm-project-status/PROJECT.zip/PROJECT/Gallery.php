<html>
<head>
</head>
<body>
    
	<table align="center">
		<tr>
			<td colspan="4" align="center">
				<h1><i>Gallery</i></h1>
				<hr>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="4 beds.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="2 beds.jpg">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="Resturant pic.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="Room.jpg">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="Spa.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="gym.jpg">
			</td>
		</tr>
	</table>
</body>
</html>