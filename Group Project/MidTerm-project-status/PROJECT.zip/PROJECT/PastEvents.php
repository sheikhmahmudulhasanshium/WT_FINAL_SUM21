<html>
    <body>
	
	<h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	Past Events </h1>
	<h2><i><b>&nbsp;&nbsp;&nbsp;1. Lunch Buffet</b></i></h2>
	<table border="6" >
	<tr><td rowspan="5"><img width="500px" height="500px" src="Lunch Buffet.jpg"></td></tr>
	<tr><td colspan="2"><h1> &nbsp;  Lunch Buffet</h1><br>
	&nbsp; Our delicious Lunch buffet is back at our signature buffet restaurant. &nbsp;<br>
	&nbsp; Enjoy a Variety of food items.
	</td></tr>
	<tr><td><b> &nbsp; Time: </b></td><td> &nbsp; 21st May to 25th May; 7.30 PM to 11.00 PM </td></tr>
	<tr><td><b>&nbsp;Available For: </b></td><td> &nbsp; Everyone </td></tr>
	</table>
	
	<h2><i><b>&nbsp;&nbsp;&nbsp;2. New Year Event</b></i></h2>
	<table border="6" >
	<tr><td rowspan="5"><img width="500px" height="500px" src="New Year.jpg"></td></tr>
	<tr><td colspan="2"><h1> &nbsp; New Year Event</h1><br>
	&nbsp; Let's celebrate New Year together with full of happiness.  &nbsp;<br>
	&nbsp; Enjoy a Variety of amazing food items.
	</td></tr>
	<tr><td><b> &nbsp; Time: </b></td><td> &nbsp; 30th December to 5th January; 7.30 PM to 11.00 PM </td></tr>
	<tr><td><b>&nbsp;Available For: </b></td><td> &nbsp; Everyone </td></tr>
	</table>
	
	</body>
</html>