<html>
<head>
</head>
<body>
	<table align="center">
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan="3" align="center"><h1>Manager Panel</h1></td>
		</tr>
		<tr>
			<td colspan="3"><hr></td>
		</tr>
		<tr>
			<td>Want to Add Category?<td>
			<td><a href ="AddCatagory.php"><input type="button" value="Add"> </a></td>
		</tr>
		<tr>
			<td>Want to Edit Category?<td>
			<td><a href ="EditCatagory.php"><input type="button" value="Edit"> </a></td>
		</tr>
		<tr>
			<td>Want to Edit Customer?<td>
			<td><a href ="EditCustomerProfile.php"><input type="button" value="Edit"> </a></td>
		</tr>
	</table>		
</body>			
</html>