<html>
    <body>
	
	<h1> Events </h1>
	<table>
	<tr><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td><td>
	
	<?php
	echo "<form action ='UpcomingEvents.php' method='post'>";
	echo "<input type= 'submit' value= 'Upcoming Events'>";
	?>
	</td></tr>
	<tr><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td><td>
	
	<?php
	echo "<form action ='PastEvents.php' method='post'>";
	echo "<input type= 'submit' value= 'Past Events'>";
	?>
	</td></tr>
	</table>
	<table>
	<tr><td><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<br><img width="400px" height="400px" src="Events.jpg"></td></tr>
	</table>
	</body>
</html>