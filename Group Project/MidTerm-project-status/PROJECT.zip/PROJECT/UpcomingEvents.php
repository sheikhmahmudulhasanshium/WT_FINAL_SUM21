<html>
    <body>
	
	<h1 style="color:green">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	Upcoming Events </h1>
	<h2><i><b>&nbsp;&nbsp;&nbsp;1. Dinner Buffet</b></i></h2>
	<table border="6" >
	<tr><td rowspan="5"><img width="500px" height="500px" src="Dinner Buffet.jpg"></td></tr>
	<tr><td colspan="3"><h1> &nbsp;  Dinner Buffet</h1><br>
	&nbsp; Our delicious Dinner buffet is back at our signature buffet restaurant curry leaf. &nbsp;<br>
	&nbsp; Enjoy a Variety of food items.
	</td>
	
	</tr>
	
	<tr><td><b> &nbsp; Time: </b></td><td> &nbsp; 21st July to 25th July; 7.30 PM to 11.00 PM </td></tr>
	<tr><td><b>&nbsp;Available For: </b></td><td> &nbsp; Everyone </td> 
	<td>
	<!--<a href = "EventBooking1.php"><input type="button" value="Book for the event"> </a>-->
	<?php
	echo "<form action='EventBooking1.php' method='post'>";
	echo "<input type='submit' value='Book for the event'>";
	echo "</form>";
	?>
	</td></tr>
	</table>
	
	<h2><i><b>&nbsp;&nbsp;&nbsp;2. Eid Event</b></i></h2>
	<table border="6" >
	<tr><td rowspan="5"><img width="500px" height="500px" src="Eid Event.jpg"></td></tr>
	<tr><td colspan="3"><h1> &nbsp; Eid Event</h1><br>
	&nbsp; Let's celebrate Eid together with full of happiness.  &nbsp;<br>
	&nbsp; Enjoy a Variety of amazing food items.
	</td></tr>
	<tr><td><b> &nbsp; Time: </b></td><td> &nbsp; 25th June to 5th July; 7.30 PM to 11.00 PM </td></tr>
	<tr><td><b>&nbsp;Available For: </b></td><td> &nbsp; Everyone </td>
	<td>
	<!--<a href = "file:///C:/xampp/htdocs/WT_D/EventBooking.html"><input type="submit" value="Book for the event"> </a>-->
	<?php
	echo "<form action='EventBooking2.php' method='post'>";
	echo "<input type='submit' value='Book for the event'>";
	echo "</form>";
	?>
	</td></tr>
	</table>
	
	</body>
</html>