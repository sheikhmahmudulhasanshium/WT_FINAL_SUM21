<html>
    <body>
	
	<img width="400px" height="300px" src="Pictures/Buffet2.jpg">
	<img width="400px" height="300px" src="Pictures/Buffet3.jpg">
	<img width="400px" height="300px" src="Pictures/Buffet4.jpg">
	
	<table border="5" align="center">
	
	<tr><td colspan="10" align="center"> <h3><br>Buffet Menu</h3></td></tr>
	<tr><td colspan="2" align="center"> <b>Chinese Items </b></td>
	<td colspan="2" align="center"><b>Vegetable Items</b></td>
	<td colspan="2" align="center"><b>Rice Items</b></td>
	</tr>
	
	<tr><td>1</td><td>Chinese noodles</td> <td>1</td><td>Vegetable noodles</td><td>1</td><td>Special Fried Rice</td></tr>
	<tr><td>2</td><td>Hot and Sour Soup</td> <td>2</td><td>Special Vegetable Soup</td><td>2</td><td>Vegetable BBQ Fried Rice</td></tr>
	<tr><td>3</td><td>Vegetable Soup</td><td>3</td><td>Vegetable Mexican Curry</td></td><td>3</td><td>Plain Rice</td></tr>
	<tr><td>4</td><td>Szechwan Chilli Chicken</td><td>4</td><td>Vegetable Chilli curry</td></td><td>4</td><td>Chicken Biriyani</td></tr>
	<tr><td>5</td><td>Spring Rolls</td><td>5</td><td>Spring Vegetable Rolls</td><td>5</td><td>Tehari</td></tr>
	<tr><td>6</td><td>Stir Fried Tofu with Rice</td><td>6</td><td>Vegetable Chicken Curry</td><td>6</td><td>Mutton Kacchi</td></tr>
	<tr><td>7</td><td>Chinese special Cheicken Curry</td><td>7</td><td>Special Vegetable Salad</td></tr>
	<tr><td>8</td><td>Chicken with Chestnuts</td></tr>
	<tr><td>9</td><td>Honey Chilli Potato</td></tr>
	<tr><td>10</td><td>Peri Peri Chicken Satay</td></tr>
	
	<tr><td colspan="2" align="center"><b>Curry</b></td>
	<td colspan="2" align="center"><b>Dessert</b></td></tr>
	
	<tr><td>1</td><td>Special Chicken Curry</td><td>1</td><td>Strawberry Cake</td></tr>
	<tr><td>2</td><td>Vegetable BBQ Curry</td><td>2</td><td>Chocolate Cake</td></tr>
	<tr><td>3</td><td>Spicy Beef Curry</td><td>3</td><td>Browny</td></tr>
	<tr><td>4</td><td>Kala Vuna</td><td>4</td><td>Chocolate Ice-Cream</td></tr>
	<tr><td>5</td><td>Chicken Curry with Mashrooms</td><td>5</td><td>Fruits</td></tr>
	<tr><td>6</td><td>Prawn Curry</td></tr>
	<tr><td>7</td><td>Khichuri</td></tr>
	
	</table>
	
	</form>
	
	</body>
</html>