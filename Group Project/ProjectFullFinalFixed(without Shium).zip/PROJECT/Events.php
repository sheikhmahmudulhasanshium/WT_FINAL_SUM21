<html>
    <body>
	
	<h1> Events </h1>
	<table>
	<tr><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td><td>
	
	<?php
	echo "<form action ='UpcomingEvents.php' method='post'>";
	echo "<input type= 'submit' value= 'Upcoming Events'>";
	echo "</form>";
	?>
	</td></tr>
	<tr><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td><td>
	
	<?php
	echo "<form action ='PastEvents.html' method='post'>";
	echo "<input type= 'submit' value= 'Past Events'>";
	echo "</form>";
	?>
	</td></tr>
	</table>
	<table>
	<tr><td><td></td><td></td><td></td><td></td><td></td><td></td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<td></td><td></td><td></td><td></td><td></td><td></td></td><td>
	<br><img width="400px" height="400px" src="Pictures/Events.jpg"></td></tr>
	</table>
	</body>
</html>