<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
    
	<table align="center" style="background-color:rgb(240, 240, 240); width:100%; height:5%;">
		<tr>
			<td>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;Hotline Number:&nbsp;+88019xxxxxxxx,&nbsp;+88018yyyyyyyy</p>
			</td>
			<td>
				<p  style="font-size: 150%;"><b><i>*HOTEL BLUE OCEAN*</i></b></p>
			</td>
			<td align="right">
				<a href="HomePageF.php" class="btn btn-info">HOME</a>
				&nbsp;&nbsp;<a href="Login.php" class="btn btn-danger">LOG OUT</a>
			</td>
		</tr>
		<tr>
			<td colspan="4">
			</td>
			<td colspan="3">
			</td>
		</tr>
		<tr>
			<td colspan="4">
			</td>
			<td colspan="3">
			</td>
		</tr>
		
	</table>